<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('peminjaman', function (Blueprint $table) {
            $table->id(); // unsigned big integer, primary key, auto increment
            $table->unsignedBigInteger('buku_id'); // foreign key ke table buku (id)
            $table->string('peminjam', 255);
            $table->date('tanggal_pinjam');
            $table->date('tanggal_kembali')->nullable(); // nullable (kosong jika belum dikembalikan)
            $table->timestamps();

            $table->foreign('buku_id')->references('id')->on('buku')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('peminjaman');
    }
};