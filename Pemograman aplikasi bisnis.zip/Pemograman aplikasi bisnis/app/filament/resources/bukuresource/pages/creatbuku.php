<?php

namespace App\Filament\Resources\BukuResource\Pages;

use App\Filament\Resources\BukuResource;
use Filament\Resources\Pages\CreateRecord;

class CreateBuku extends CreateRecord
{
    protected static string $resource = BukuResource::class;

    protected function getRedirectUrl(): string
    {
        // Setelah berhasil membuat buku, arahkan kembali ke halaman daftar buku.
        return $this->getResource()::getUrl('index');
    }
}