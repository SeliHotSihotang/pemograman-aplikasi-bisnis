<?php

namespace App\Filament\Resources\PeminjamanResource\Pages;

use App\Filament\Resources\PeminjamanResource;
use Filament\Resources\Pages\CreateRecord;

class CreatePeminjaman extends CreateRecord
{
    protected static string $resource = PeminjamanResource::class;

    protected function getRedirectUrl(): string
    {
        // Setelah berhasil membuat peminjaman, arahkan kembali ke halaman daftar peminjaman.
        return $this->getResource()::getUrl('index');
    }
}