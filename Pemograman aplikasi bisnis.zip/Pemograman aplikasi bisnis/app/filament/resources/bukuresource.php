<?php

namespace App\Filament\Resources;

use App\Filament\Resources\BukuResource\Pages;
use App\Models\Buku;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables\Actions;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class BukuResource extends Resource
{
    protected static ?string $model = Buku::class;

    protected static ?string $navigationIcon = 'heroicon-o-book-open';
    protected static ?string $navigationLabel = 'Manajemen Buku';
    protected static ?string $modelLabel = 'Buku';
    protected static ?string $pluralModelLabel = 'Buku-buku'; // Label untuk jamak

    public static function form(Form $form): Form
    {
        return $form
            ->schema([
                TextInput::make('judul')
                    ->required()
                    ->maxLength(255)
                    ->placeholder('Masukkan judul buku'),
                TextInput::make('pengarang')
                    ->required()
                    ->maxLength(255)
                    ->placeholder('Masukkan nama pengarang'),
                Select::make('kategori')
                    ->options([
                        'Fiksi' => 'Fiksi',
                        'Non Fiksi' => 'Non Fiksi',
                    ])
                    ->required()
                    ->placeholder('Pilih kategori buku'),
            ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('judul')
                    ->searchable()
                    ->sortable()
                    ->label('Judul'),
                TextColumn::make('pengarang')
                    ->searchable()
                    ->sortable()
                    ->label('Pengarang'),
                TextColumn::make('kategori')
                    ->searchable()
                    ->sortable()
                    ->label('Kategori'),
                IconColumn::make('is_available')
                    ->label('Tersedia')
                    ->boolean()
                    // Menggunakan scope 'tersedia' untuk menentukan apakah buku tersedia
                    ->getStateUsing(fn (Buku $record): bool => Buku::where('id', $record->id)->tersedia()->exists())
                    ->tooltip(fn (Buku $record): string => $record->tersedia()->exists() ? 'Buku ini tersedia untuk dipinjam' : 'Buku ini sedang dipinjam'),
            ])
            ->filters([
                // Anda bisa menambahkan filter di sini, misalnya berdasarkan kategori
                Select::make('kategori')
                    ->options([
                        'Fiksi' => 'Fiksi',
                        'Non Fiksi' => 'Non Fiksi',
                    ])
                    ->placeholder('Filter berdasarkan kategori'),
            ])
            ->actions([
                Actions\EditAction::make(),
                Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Actions\BulkActionGroup::make([
                    Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            // Jika ada relasi manager, tambahkan di sini
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListBukus::route('/'),
            'create' => Pages\CreateBuku::route('/create'),
            'edit' => Pages\EditBuku::route('/{record}/edit'),
        ];
    }
}